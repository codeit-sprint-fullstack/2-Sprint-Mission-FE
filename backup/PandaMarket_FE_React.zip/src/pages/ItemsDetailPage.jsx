function ItemsDetailPage() {}

export default ItemsDetailPage;
